from .bot import main

main()