from .test import main

main()