# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pythontest']

package_data = \
{'': ['*']}

install_requires = \
['dazl>=7.1.2,<8.0.0']

setup_kwargs = {
    'name': 'pythontest',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'star123good',
    'author_email': 'star921str@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
